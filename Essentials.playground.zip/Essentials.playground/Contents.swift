import Foundation


let myName = "Vandad" // let cannot be assigned to again
var yourName = "Foo" // var can be assigned to again

// myName = yourName     // cause a problem

yourName = "Mu"


var names = [myName,yourName]

names.append("Baz") // this wouldn't work if names was let

// With let we cannot assign a new value and we cannot mutate it but with var we can do both

let myAge = 22
let yourAge = 20

if myAge > yourAge {
    "I'm older than you"
}
else if myAge < yourAge {
    "I'm younger than you"
}
else {
    "Oh hey, we are the same age"
}

let stringWithQuotes = "here it is \" and once more \" "

let name = "Taylor"
let age = 26
let message = "I'm \(name) and I'm \(age) years old."
print(message)

// All of array's variables must match i'ts type (strings, ints , etc...)

let employee = ["name": "Taylor", "job": "Singer"] // A Dictionary data type
print(employee["job", default: "Unknown"])


var numbers = Set([1,1,3,5,7,9])
print(numbers)   // the order is gone because it's a set

numbers.insert(10)
numbers.contains(11)  // will run instantly opposed to an array


// Enum is a set of name values we can use
enum Weekday {
    case monday,tuesday, wednesday, thursday, friday
}

var day = Weekday.monday
day = .friday


// I can try to force a type on a var using type annotation
var score: Double = 0
let player: String = "Roy"

var albums: Array<String> = ["red", "fearless"]
var user: Dictionary<String,String> = ["red": "fearless"]
// its the same as
//var albums: [String] = ["red", "fearless"]
//var user: [String,String] = ["red", "fearless"]
var books: Set<String> = Set(["the blue", "found"])

// in a condition: && - and , || - or

switch day {
case .friday:
    print("nice")
case .monday:
    print("holy crap")
default: // for any other value
    print("whatever")
}


for i in 1...10 {
    print(i)
}

func sayCheese (times: Int) {
    for _ in 0...times {
        print("cheese")
    }
}

sayCheese(times: 2)


func rollDice() -> Int {
    return Int.random(in: 1...6) // return can be omitted
}

print(rollDice())

// return can be omitted
func rollDiceNoReturn() -> Int {
    Int.random(in: 1...6) // return can be omitted for one line functions
}

print(rollDiceNoReturn())

// we can use closure

let sayHello = { (name:String) -> String in // the "in" keyword marks the end of the segment and the start of the body
    "Hi, \(name)!"
}

print(sayHello("Zuri"))

struct Album {
    let title: String
    let artist: String
    var isReleased = true
    
    // init is not a must
//    init(title: String){
//        self.title = title
//    }
    
    func printSummary() {
        print("\(title) by \(artist)")
    }
    // mutating must mark when struct member can be changed
    mutating func removeFromSale() {
        isReleased = false
    }
    
}

let red = Album(title: "Red", artist: "Taylor Swift")
print(red.title)
red.printSummary()

// access control for structs:
// private
// private(set) - (only internal things can write to it)
// file private - (anything inside the current file can read\write it
// public

// static let us read without creating an object of the struct
struct AppData {
    static let version = "1.3 beta 2"
}

print(AppData.version)


// class gives us also inheritance
class Employee {
    let hours:Int
    
    init(hours:Int){
        self.hours = hours
    }
    
    func printSummary() {
        print("I work \(hours) hours a day.")
    }
}

class Developer: Employee {
    func work() {
        print("I'm coding for \(hours) hours a day.")
    }
    
    // can use the override keyword to change parents method
}

let novall = Developer(hours: 8)
novall.work()
novall.printSummary()

// protocols defines functionallity we expect other types to support
